"""Section II report generator."""
